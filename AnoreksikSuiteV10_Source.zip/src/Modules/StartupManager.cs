using System;
using System.Windows.Forms;
using System.Drawing;
using Microsoft.Win32;
using System.Collections.Generic;

namespace AnoreksikSuite {
    public partial class MainForm {
        private TabPage startupPage;
        private ListBox lstStartup;
        private TextBox txtStartupName, txtStartupPath;
        
        private void InitTab_Startup() {
            startupPage = new TabPage("BASLANGIC");
            startupPage.BackColor = Color.FromArgb(30,30,30);
            startupPage.Name = "STARTUP";
            
            CreateLabel("Baslangic Ogeleri (Registry Run)", 10, 10, 10, startupPage).ForeColor = Color.Yellow;
            
            lstStartup = new ListBox();
            lstStartup.Location = new Point(10, 40);
            lstStartup.Size = new Size(660, 300);
            lstStartup.BackColor = Color.Black;
            lstStartup.ForeColor = Color.Lime;
            startupPage.Controls.Add(lstStartup);
            
            Button btnRefresh = CreateBtn("YENILE", 10, 350, 150, Color.Gray, startupPage);
            btnRefresh.Click += (s,e) => RefreshStartupList();
            
            Button btnDelete = CreateBtn("SIL", 170, 350, 150, Color.Red, startupPage);
            btnDelete.Click += (s,e) => DeleteStartupItem();
            
            GroupBox gAdd = CreateGroup("Yeni Ekle", 10, 400, 660, 120, startupPage);
            CreateLabel("Ad:", 10, 25, gAdd);
            txtStartupName = new TextBox(); txtStartupName.Location = new Point(50, 22); txtStartupName.Size = new Size(200, 20); gAdd.Controls.Add(txtStartupName);
            
            CreateLabel("Yol:", 10, 55, gAdd);
            txtStartupPath = new TextBox(); txtStartupPath.Location = new Point(50, 52); txtStartupPath.Size = new Size(400, 20); gAdd.Controls.Add(txtStartupPath);
            
            Button btnBrowse = CreateBtn("...", 460, 50, 40, Color.Gray, gAdd);
            btnBrowse.Height = 23;
            btnBrowse.Click += (s,e) => {
                OpenFileDialog ofd = new OpenFileDialog();
                if (ofd.ShowDialog() == DialogResult.OK) txtStartupPath.Text = ofd.FileName;
            };
            
            Button btnAdd = CreateBtn("EKLE", 520, 20, 100, Color.DarkGreen, gAdd);
            btnAdd.Height = 60;
            btnAdd.Click += (s,e) => AddStartupItem();
            
            RefreshStartupList();
            tabs.TabPages.Add(startupPage);
        }
        
        private void RefreshStartupList() {
            lstStartup.Items.Clear();
            try {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run")) {
                    if (key != null) {
                        foreach (string v in key.GetValueNames()) {
                            lstStartup.Items.Add("[HKCU] " + v + " = " + key.GetValue(v));
                        }
                    }
                }
                using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run")) {
                    if (key != null) {
                        foreach (string v in key.GetValueNames()) {
                            lstStartup.Items.Add("[HKLM] " + v + " = " + key.GetValue(v));
                        }
                    }
                }
            } catch { }
        }
        
        private void DeleteStartupItem() {
            if (lstStartup.SelectedItem == null) return;
            string item = lstStartup.SelectedItem.ToString();
            string name = item.Substring(7, item.IndexOf(" = ") - 7);
            bool isHkcu = item.StartsWith("[HKCU]");
            
            try {
                if (isHkcu) {
                    using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                        key.DeleteValue(name);
                } else {
                    using (RegistryKey key = Registry.LocalMachine.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                        key.DeleteValue(name);
                }
                RefreshStartupList();
            } catch (Exception ex) { SafeMessageBox("Hata: " + ex.Message); }
        }
        
        private void AddStartupItem() {
            if (string.IsNullOrEmpty(txtStartupName.Text) || string.IsNullOrEmpty(txtStartupPath.Text)) return;
            try {
                using (RegistryKey key = Registry.CurrentUser.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Run", true))
                    key.SetValue(txtStartupName.Text, txtStartupPath.Text);
                RefreshStartupList();
                SafeMessageBox("Eklendi!");
            } catch (Exception ex) { SafeMessageBox("Hata: " + ex.Message); }
        }
    }
}
