# Anoreksik Suite V10 Source Code

This directory contains the source code for Anoreksik Suite V10, refactored into multiple files for better maintainability and modularity.

## Structure

*   `Program.cs`: Entry point of the application.
*   `MainForm.cs`: Main form class, containing core logic and initialization.
*   `NativeMethods.cs`: P/Invoke declarations for Windows APIs.
*   `Modules/`: Contains partial class implementations for each tab/feature.
    *   `WifiModule.cs`: WiFi Watchdog and optimization (Fixed infinite loop/startup bug).
    *   `ActivityWatcher.cs`: **NEW** Tracks active window and usage time.
    *   `StartupManager.cs`: **NEW** Manage Registry Run keys.
    *   `SecurityModule.cs`: **NEW** TinyWall-like features and AV scanning (Hash-based).
    *   `PasswordManager.cs`: **NEW** Secure password storage (AES).
    *   `SystemInfo.cs`: **NEW** Detailed system information (WMI).
    *   `ToolsModule.cs`: **NEW** Alarm, Terminal, VPN shortcuts.
    *   `LegacyModules.cs`: Placeholders/Ports of original RAM/CPU/DISK modules.

## Compilation

To compile this project, you need a C# compiler (Visual Studio, Roslyn, or `csc`).

Create a new Windows Forms Project (.NET Framework 4.7.2 or higher recommended) and include all files in the `src` directory.

## Features Added

*   **Modular Architecture**: Split into multiple files.
*   **Activity Watcher**: Tracks usage.
*   **Startup Manager**: Registry Run editor.
*   **Security Tab**: Firewall controls and File Hashing.
*   **Password Manager**: Encrypted storage.
*   **System Info**: Detailed hardware info.
*   **Fixes**: WiFi Watchdog checkbox logic fixed.

## Note
Ensure you run the application as Administrator for all features to work correctly (Service management, Registry access, etc.).
